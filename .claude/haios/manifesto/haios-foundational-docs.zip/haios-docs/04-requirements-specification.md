# HAIOS Requirements Specification

*This document bridges three foundational documents — The Measure (foundational theory), The Operating Framework (principles, policy, rhythm), and The Harness (infrastructure design) — into buildable requirements. It is written to be consumed by any doc-to-product pipeline, including the current HAIOS Chariot.*

*Every requirement traces to its source document(s) and reduces to the three primitives: Agents, Messages, Context.*

*This document does not prescribe implementation. It states what the system must do and why. The how is the pipeline's problem.*

---

## Traceability Key

**Source tags:**
- `[M]` — The Measure (foundational theory, timing, rhythm)
- `[F]` — The Operating Framework (principles, ways of working, ceremonies, activities, assets)
- `[H]` — The Harness (infrastructure, bus, routing, plumbing)

**Primitive tags:**
- `[A]` — Agents
- `[Msg]` — Messages
- `[Ctx]` — Context

**Priority:**
- `P0` — Buildable now by current Chariot. No dependencies on unbuilt systems.
- `P1` — Buildable once P0 is in place. Requires P0 outputs as inputs.
- `P2` — Requires the larger architecture. Harness/bus infrastructure or multi-system integration.
- `P3` — Requires evolved capabilities (trained models, autonomous operation). Vision-tier.

---

## R1: Decision Logging

Every decision the system makes must be captured with sufficient detail to serve as future training data.

**What:** All routing decisions, tool invocations, escalations, and their outcomes are recorded in a structured, append-only log.

**Why:** The system's memory is its primary asset `[F.2]`. State is filtered event history `[H]`. Observability receives all emissions `[H]`. Without this, no ceremony has data to work with and no learning loop can function.

**A decision log entry contains:**
- What was decided (the action taken)
- What alternatives existed (other possible actions)
- What confidence level, if any, informed the decision
- What the outcome was (success, failure, partial)
- What agent made the decision
- Timestamp

**Traces to:** `[F] Principle 2`, `[H] Observability system`, `[M] Observe phase`
**Primitives:** `[Msg]` `[A]`
**Priority:** `P0`

**Acceptance:** A query against the log can answer "what did agent X decide at time Y, and what happened?"

---

## R2: Confidence Scoring

Decisions that involve routing, classification, or selection must carry a confidence score.

**What:** When an agent selects a path — which tool, which escalation target, which action — it outputs a confidence value alongside the decision. The score is stored in the decision log.

**Why:** Confidence governs flow `[F.3]`. Without measured uncertainty, the system cannot distinguish between decisions it should trust and decisions it should escalate. Thresholds cannot be tuned without scores to tune against.

**Traces to:** `[F] Principle 3`, `[M] Harmonic Principle (thresholds are hypotheses)`
**Primitives:** `[A]` `[Msg]`
**Priority:** `P0`

**Acceptance:** A distribution of confidence scores can be plotted for any agent over any time period.

---

## R3: Message Bus

Agents communicate exclusively through a shared messaging substrate. No direct agent-to-agent coupling.

**What:** A message routing system that accepts messages from any agent, routes them by type and destination, tracks message state (pending, claimed, complete), and supports threaded conversations.

**Why:** Routing is the only infrastructure concern `[H]`. The handoff is the primitive `[H]`. Currently Ruben is the message bus `[H]` — the target state is substrate handling handoffs.

**A message contains:**
- Unique ID
- Thread ID (groups related messages)
- Source agent
- Destination agent
- Type (artifact, question, answer, command)
- Payload (content or reference)
- State (pending, claimed, complete)
- Timestamp

**Traces to:** `[H] Message Primitive`, `[H] Bus Components`, `[F] Principle 1 (cheapest viable resolution)`
**Primitives:** `[Msg]` `[A]`
**Priority:** `P1`

**Acceptance:** Two agents can exchange messages through the bus without knowledge of each other's implementation. An inbox query returns pending messages for a given agent. A thread query returns ordered message history.

---

## R4: Capability Registry

The system must maintain a declarative registry of everything it can do — every tool, agent, script, and MCP server — described in a format that enables discovery without hardwiring.

**What:** A searchable store of capability descriptions. Each entry includes: name, description of what it does, input schema, output schema, usage examples. New capabilities are added by inserting a description, not by modifying routing code.

**Why:** Capabilities enter declaratively `[F]`. New capabilities are immediately available, eventually learned `[F.5]`. The system discovers what it can do `[F]`. This is the vector store in the cascade architecture — the retrieval layer that makes new tools usable before they're trained into the model.

**Traces to:** `[F] Principle 5`, `[F] Way of Working: capabilities enter declaratively`, `[H] Agent registry (deferred in Harness, required here)`
**Primitives:** `[Ctx]` `[A]`
**Priority:** `P0`

**Acceptance:** A new tool can be added to the system by writing a single description document. The system can answer "what tool best matches this intent?" by searching the registry.

---

## R5: Cascade Router

Decision routing must follow a layered escalation pattern: cheapest resolution first, escalating only when confidence is insufficient.

**What:** A routing component that attempts resolution at the lowest-cost layer, checks confidence against a threshold, and escalates to the next layer if confidence is below threshold. Minimum two layers: fast/cheap (local lookup or trained model) and slow/expensive (API call to capable LLM). The router logs which layer resolved each decision.

**Why:** Cheapest viable resolution first `[F.1]`. The system teaches itself `[F.4]`. Expensive decisions today become cheap decisions tomorrow. Layer 2 (retrieval) catches edge cases and new tools. Layer 3 (big LLM) provides the ground truth that trains Layer 1.

**Traces to:** `[F] Principles 1 and 4`, `[H] Daemon/invocation model`, `[M] The system teaches itself`
**Primitives:** `[A]` `[Ctx]` `[Msg]`
**Priority:** `P1`

**Acceptance:** The percentage of decisions resolved at each layer is measurable. Over time, the percentage at the cheapest layer increases.

---

## R6: Daily Signal Compression

At the boundary of each active/rest cycle, accumulated decision logs must be compressed into a summary signal.

**What:** A process that runs at the end of each active period (session, working day, or equivalent) that reads the day's decision logs and produces a compressed summary: total decisions, confidence distribution, failure rate, anomalies flagged, new capabilities used, escalation frequency by layer.

**Why:** The circadian cycle is the boundary between operation and consolidation `[M]`. Daily signals are an asset `[F]`. Pulse data accumulates during the active phase; the rest phase compresses it. Without compression, the system drowns in raw logs and ceremonies have no signal to work with.

**Traces to:** `[M] Circadian cycle`, `[F] Activities: compressing pulse data into daily signals`, `[F] Assets: daily signals`
**Primitives:** `[Msg]` `[Ctx]`
**Priority:** `P1`

**Acceptance:** A daily signal document is produced for every active day. It is queryable by date. It is small enough for a ceremony to consume without loading raw logs.

---

## R7: Calibration Ceremony Support

The system must support a periodic review process that analyses accumulated daily signals and produces actionable insights about system performance.

**What:** A queryable interface that, given a time range, returns: aggregated performance across the period, threshold drift (are current confidence thresholds still appropriate?), accuracy trends by layer, tools or intents that are degrading, and candidates for retraining or threshold adjustment.

**Why:** Calibration is the lunar-scale ceremony `[F]`. Thresholds are hypotheses `[F]`. Without structured review, thresholds ossify and the system stops improving. The measure measures itself `[F.6]`.

**Traces to:** `[M] Lunar cycle`, `[F] Ceremony: Calibration`, `[F] Principle 6`
**Primitives:** `[Ctx]`
**Priority:** `P1`

**Acceptance:** Running calibration over the last cycle produces a report that a human or orchestrator agent can act on. The report identifies at least: thresholds that should change, capabilities that are underperforming, and escalation patterns that suggest training opportunities.

---

## R8: Evolution Ceremony Support

The system must support a periodic learning cycle that acts on calibration insights to retrain, reconfigure, or retire system components.

**What:** A process that consumes calibration output and executes changes: retraining a model on accumulated data, updating confidence thresholds, adding or removing capabilities from the registry, updating routing rules. It records a before/after performance snapshot.

**Why:** The system teaches itself `[F.4]`. Evolution is the lunar-scale action ceremony `[F]`. What is expensive today becomes cheap tomorrow. Without a structured evolution cycle, insights from calibration are observed but never acted on.

**Traces to:** `[M] Lunar cycle (acted upon)`, `[F] Ceremony: Evolution`, `[F] Activities: retraining and updating learned components`
**Primitives:** `[A]` `[Ctx]`
**Priority:** `P2`

**Acceptance:** After an evolution cycle, the system's performance baseline is measurably different from before. The change is recorded in the performance baselines asset.

---

## R9: Thread Lifecycle

Conversations between agents must have a finite lifecycle with clear state transitions.

**What:** Threads are created (open), accumulate messages (active), produce a result, and close. Closed threads do not reopen. New work referencing old threads creates a new thread. Thread outcomes flow into shared context (Org). Thread history flows into observability.

**Why:** Threads are transactions, not conversations `[H]`. The four-phase cycle (Observe → Accumulate → Consolidate → Emerge changed) applies at thread scale `[M]`. State emerges from history `[H]`.

**Traces to:** `[H] Thread Lifecycle`, `[M] Four-phase cycle`, `[H] Three-system architecture (outcomes → Org, history → Observability)`
**Primitives:** `[Msg]`
**Priority:** `P1`

**Acceptance:** No thread exists in an ambiguous state. Every thread is open, active, or closed. Closed threads are immutable. A query can return all open threads, all threads for an agent, or thread history by ID.

---

## R10: Shared Reference Context (Org)

The system must maintain a shared body of reference data that all agents can access — what things are, not what to do with them.

**What:** A data store containing entity definitions, relationship maps, domain knowledge, and configuration that agents consult to understand their operating context. Separate from coordination (what to do next) and observability (what happened).

**Why:** Context shapes behaviour `[H]`. Same agent, different context, different capability `[H]`. The three-system architecture separates coordination, org, and observability for good reason — they have different temporal and access patterns `[H]`.

**Traces to:** `[H] Three-system architecture: Org`, `[H] Essential truths: context determines behaviour`
**Primitives:** `[Ctx]`
**Priority:** `P2`

**Acceptance:** An agent can query the Org for "what is entity X?" and receive a consistent answer regardless of which agent asks. Org state is updated by thread outcomes, not by individual agent decisions.

---

## R11: Observability as Feedback Source

Observability must not be a passive archive. It must be queryable in ways that feed ceremonies and learning loops.

**What:** The observability system (decision logs, message history, emissions) must support temporal queries: "what happened in the last N days?", "what failed this cycle?", "what patterns appear across threads?" It must emit data in formats that daily signal compression (R6) and calibration (R7) can consume.

**Why:** Currently observability is downstream-only `[H]` — it receives but doesn't feed back. The Operating Framework requires it to feed ceremonies. Every execution is training data `[F.2]` is meaningless if the training data isn't accessible at ceremony time.

**Traces to:** `[F] Principle 2`, `[F] Ceremonies (all)`, `[H] Observability system`, `[M] Observe phase`
**Primitives:** `[Msg]` `[Ctx]`
**Priority:** `P1`

**Acceptance:** The calibration ceremony (R7) can run entirely from observability queries without manual data extraction.

---

## R12: Temporal Tagging

Messages and events should carry a temporal scale indicator so the system can distinguish between operational data and ceremony-scale data.

**What:** Messages, decision logs, and system events can be tagged with a ceremony scale: pulse, daily, calibration, evolution, expansion, orbit. The bus routes as normal, but the temporal layer can query by scale.

**Why:** Not every message is equal. Some are pulse-level operations, some are calibration-level signals, some are evolution-level data. Without temporal tagging, ceremonies must scan all data to find what's relevant to their scale.

**Traces to:** `[M] The Spheres (nested temporal scales)`, `[F] Ceremonies`, `[H] Message primitive (extension)`
**Primitives:** `[Msg]`
**Priority:** `P1`

**Acceptance:** A query for "all calibration-scale events from the last lunar cycle" returns only relevant data, not the full firehose of pulse-level operations.

---

## R13: Agent Invocation Model

Agents are invoked on demand, not long-running. A watcher component detects pending work and invokes the appropriate agent.

**What:** A daemon or equivalent process that monitors inboxes for pending messages and invokes target agents. Agents do not poll. The daemon is the simplest possible implementation: check for pending, invoke, log result.

**Why:** Agents are invoked on demand `[H]`. The daemon is the proto-cascade — it starts deterministic and evolves toward learned routing. Separating invocation from execution means agents remain stateless and swappable.

**Traces to:** `[H] Agent invocation model`, `[H] Chariot metaphor (horses are stateless)`, `[F] Principle 4 (system teaches itself — the daemon learns)`
**Primitives:** `[A]` `[Msg]`
**Priority:** `P2`

**Acceptance:** An agent can be invoked by the daemon without the agent knowing it was invoked by a daemon rather than a human. The invocation path is logged.

---

## R14: Performance Baselines

The system must maintain versioned performance metrics that allow comparison across ceremony cycles.

**What:** At each evolution cycle, a performance snapshot is recorded: decision accuracy, latency, cost-per-decision, escalation rates, layer utilisation percentages. Snapshots are versioned and comparable.

**Why:** Performance baselines are an asset `[F]`. The proof the system is improving. Without baselines, "the system is getting better" is a feeling, not a measurement. The measure measures itself `[F.6]`.

**Traces to:** `[F] Assets: performance baselines`, `[F] Principle 6`, `[M] The Hermetic Frame (emerge changed — prove it)`
**Primitives:** `[Ctx]`
**Priority:** `P2`

**Acceptance:** A query can return performance baselines for any two ceremony cycles. The delta between them is computable.

---

## R15: Timing Performance Data

The system must track whether its ceremony rhythms actually produce better outcomes than arbitrary scheduling.

**What:** Ceremony outcomes (what calibration found, what evolution changed, how expansion redirected) are recorded alongside the timing of when they ran. Over time, this data answers: does lunar-aligned calibration outperform calendar-monthly? Does seasonal expansion outperform quarterly?

**Why:** Timing hypotheses are stated in The Measure. The framework demands they be tested `[F.6]`. Rhythms are coupled, not arbitrary `[F]` — but "coupled" means tested, not assumed.

**Traces to:** `[M] Coupling, Not Mysticism`, `[F] Principle 6`, `[F] Assets: timing performance data`
**Primitives:** `[Ctx]`
**Priority:** `P3`

**Acceptance:** After one full orbit (annual cycle), the system can report whether its timing choices outperformed a baseline schedule.

---

## R16: Pattern Library

Each instance of the framework applied to a new domain must be documented as a reusable pattern.

**What:** When the cascade/framework is applied to a new domain (tool routing, record classification, content triage, etc.), the application is recorded: what the domain was, how the primitives mapped, what thresholds were set, what worked and didn't. These become the playbook for expansion.

**Why:** Pattern library is an asset `[F]`. Expansion ceremonies need a playbook `[F]`. The framework is pattern-agnostic — but each application teaches something about how the pattern behaves in different contexts.

**Traces to:** `[F] Assets: pattern library`, `[F] Ceremony: Expansion`
**Primitives:** `[Ctx]`
**Priority:** `P2`

**Acceptance:** A new domain can be onboarded faster by consulting existing patterns than by starting from scratch.

---

## R17: Declarative Tool Entry

New tools, scripts, or MCP servers must be usable immediately upon description, without code changes to routing logic.

**What:** Adding a new capability requires writing a description document (name, purpose, input/output schema, examples) and inserting it into the capability registry (R4). The retrieval layer (R5, Layer 2) picks it up immediately. No router code is modified.

**Why:** New capabilities are immediately available, eventually learned `[F.5]`. The system discovers tools, it doesn't get hardwired to them `[F]`. This is what separates a living system from a static integration.

**Traces to:** `[F] Principle 5`, `[F] Way of Working: capabilities enter declaratively`, `[H] Agent registry`
**Primitives:** `[Ctx]` `[A]`
**Priority:** `P1`

**Acceptance:** A new MCP server described in one document is routable within the same session, without redeployment or code changes.

---

## R18: Human-as-Layer Logging

When a human makes a decision that the system could eventually make, that decision is logged identically to automated decisions.

**What:** Human routing decisions, manual overrides, and interventions are captured in the same decision log format as automated decisions. The log distinguishes human from automated, but the schema is identical.

**Why:** Humans are a layer, not an escape hatch `[F]`. Human decisions are the highest-cost resolution — and the richest training data. If human decisions aren't logged, the system can never learn to replace them.

**Traces to:** `[F] Way of Working: humans are a layer`, `[F] Principle 4 (system teaches itself)`, `[M] The Hermetic Frame (same pattern at every scale)`
**Primitives:** `[A]` `[Msg]`
**Priority:** `P1`

**Acceptance:** A calibration report can show what percentage of decisions were human vs automated, and whether that percentage is decreasing over time.

---

## Dependency Map

```
R1 (Decision Logging) ← foundation, no deps
R2 (Confidence Scoring) ← foundation, no deps
R4 (Capability Registry) ← foundation, no deps

R3 (Message Bus) ← R1
R5 (Cascade Router) ← R2, R4
R6 (Daily Signal Compression) ← R1
R9 (Thread Lifecycle) ← R3
R11 (Observability as Feedback) ← R1, R6
R12 (Temporal Tagging) ← R3
R17 (Declarative Tool Entry) ← R4
R18 (Human-as-Layer Logging) ← R1

R7 (Calibration Support) ← R6, R11
R10 (Shared Reference Context) ← R9
R13 (Agent Invocation) ← R3, R5
R14 (Performance Baselines) ← R7

R8 (Evolution Support) ← R7, R5
R15 (Timing Performance Data) ← R14
R16 (Pattern Library) ← R8
```

---

## Primitive Coverage

| Requirement | Agents | Messages | Context |
|---|---|---|---|
| R1 Decision Logging | ✓ | ✓ | |
| R2 Confidence Scoring | ✓ | ✓ | |
| R3 Message Bus | ✓ | ✓ | |
| R4 Capability Registry | ✓ | | ✓ |
| R5 Cascade Router | ✓ | ✓ | ✓ |
| R6 Daily Signal Compression | | ✓ | ✓ |
| R7 Calibration Support | | | ✓ |
| R8 Evolution Support | ✓ | | ✓ |
| R9 Thread Lifecycle | | ✓ | |
| R10 Shared Reference Context | | | ✓ |
| R11 Observability as Feedback | | ✓ | ✓ |
| R12 Temporal Tagging | | ✓ | |
| R13 Agent Invocation | ✓ | ✓ | |
| R14 Performance Baselines | | | ✓ |
| R15 Timing Performance Data | | | ✓ |
| R16 Pattern Library | | | ✓ |
| R17 Declarative Tool Entry | ✓ | | ✓ |
| R18 Human-as-Layer Logging | ✓ | ✓ | |

All three primitives are covered. No requirement exists that doesn't touch at least one. R5 (Cascade Router) is the only requirement that touches all three — which makes sense, as it's the core architectural pattern.

---

## What the Chariot Can Build Now (P0)

Three requirements have no dependencies and map to existing Chariot capabilities:

**R1 (Decision Logging):** The Chariot already has `haios-events.jsonl` and session state tracking. Extend the schema to capture decisions in the required format. This is module work — GovernanceLayer already logs gate decisions.

**R2 (Confidence Scoring):** New concept for the Chariot, but implementable as a field on existing decision/routing outputs. No infrastructure required — it's a data model change.

**R4 (Capability Registry):** The Chariot has `components.yaml` with skill/agent/hook registries. Extend toward searchable descriptions with schemas and examples. ContextLoader already knows how to load these.

These three unlock everything else.

---

*This document is the genotype. What the pipeline expresses from it is the phenotype.*
