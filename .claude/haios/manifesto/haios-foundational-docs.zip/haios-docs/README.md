# HAIOS Foundational Document Package

*Generated: 2026-02-08*

---

## Contents

| # | Document | Purpose |
|---|----------|---------|
| 01 | **The Measure** | Foundational theory. Timing, rhythm, cosmological grounding. The physics layer. |
| 02 | **Operating Framework** | Principles, ways of working, ceremonies, activities, assets. The policy layer. |
| 03 | **Integration Analysis** | Maps the relationship between Operating Framework and The Harness. Identifies gaps. |
| 04 | **Requirements Specification** | 18 traceable requirements bridging all three foundational docs to buildable work. The genotype. |
| 05 | **Research: Schumann Resonance** | Evidence base and epistemic assessment informing The Measure's cosmological framing. |
| 06 | **Integration Brief** | Instructions for the Chariot pipeline to synthesize these documents into the existing L0-L4 manifesto. Agent-consumable. |

---

## How These Documents Relate

```
The Measure (physics — why these rhythms)
     │
     ▼
Operating Framework (policy — when and how to act)
     │
     ├──── Integration Analysis (maps Framework ↔ Harness)
     │
     ▼
Requirements Specification (genotype — what to build)
     │
     ▼
Integration Brief (how to merge into existing L0-L4)
     │
     ▼
[Chariot pipeline consumes → produces new manifesto version]
```

The Harness (Org Instance Design) is a pre-existing document not included in this package. The Integration Analysis references it.

---

## The Three Primitives (DNA)

All documents reduce to three irreducible primitives:

1. **Agents** — Actors that produce and consume
2. **Messages** — What moves between them
3. **Context** — What shapes behaviour

---

## Reading Order

For understanding: 01 → 02 → 03 → 04
For building: 06 (integration brief) → 04 (requirements) → reference 01/02/03 as needed
For research context: 05 (standalone)
For the Chariot pipeline: 06 is the entry point. It tells agents what to do with everything else.
