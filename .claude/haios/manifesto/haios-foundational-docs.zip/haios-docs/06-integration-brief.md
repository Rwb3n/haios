# HAIOS Integration Brief: Foundational Documents → Manifesto

*This document instructs the Chariot pipeline on how to integrate four new foundational documents into the existing L0-L4 manifesto structure. It is written for agent consumption.*

---

## What Happened

A design session produced four new documents that extend HAIOS beyond a single-system agent framework into a multi-system operating architecture. These documents do not replace L0-L4. They extend it.

| New Document | Purpose | Relationship to Existing |
|---|---|---|
| **The Measure** | Foundational theory. Timing, rhythm, cosmological grounding. | Sits alongside L3. Provides temporal grounding L3 doesn't have. |
| **Operating Framework** | Principles, ways of working, ceremonies, activities, assets. | Extends L3 behavioral principles. Provides the five-layer hierarchy already discovered in E2.4. |
| **Integration Analysis** | Maps the gap between the Operating Framework and The Harness. | Working document. Informs requirements. |
| **Requirements Specification** | 18 traceable requirements (R1-R18) bridging theory to buildable work. | Extends L4 REQ registry. New requirements coexist with existing REQ-* IDs. |
| **Research: Schumann Resonance** | Evidence base for The Measure's cosmological framing. | Reference material. Not operational. |

A fifth pre-existing document, **The Harness** (Org Instance Design), was produced in a prior session and specifies the inter-system message bus architecture. It is not included in this package but is referenced throughout.

---

## What Does NOT Change

**L0 (Telos)** — Unchanged. The new documents serve the Agency Engine mission. The Measure's self-improving system is an expression of L0.14 (Prime Directive). The Harness reduces cognitive load (L0.2) by removing Ruben as the message bus.

**L1 (Principal)** — Unchanged. The new architecture serves Ruben. The temporal ceremonies accommodate burnout constraints (L1.5). The cascade router reduces operator bottleneck (L1.9).

**L2 (Intent)** — Unchanged. The new architecture advances L2.1 (Self-Aware Symbiotic System), L2.7 (Leverage), and L2.9 (Freedom of Movement — system runs while operator is mobile).

**L3 (Requirements)** — Principles unchanged. The new documents provide additional structure that implements L3 principles, particularly:
- L3.1 (Certainty Ratchet) → self-improving cascade
- L3.3 (Context Must Persist) → decision logs, daily signals, performance baselines
- L3.4 (Duties Are Separated) → multi-system architecture with bus
- L3.7 (Traceability) → every requirement traced to source document and primitive

---

## What Changes

### L3 Additions

The Operating Framework's six principles should be referenced from L3 as implementation-level principles that derive from L3's behavioral principles:

| Operating Framework Principle | Derives From L3 |
|---|---|
| F.1 Cheapest viable resolution first | L3.6 (Graceful Degradation) |
| F.2 Every execution is training data | L3.7 (Traceability), L3.3 (Context Must Persist) |
| F.3 Confidence governs flow | L3.1 (Certainty Ratchet), L3.2 (Evidence Over Assumption) |
| F.4 The system teaches itself | L3.1 (Certainty Ratchet), L3.3 (Context Must Persist) |
| F.5 New capabilities immediately available, eventually learned | L3.6 (Graceful Degradation) |
| F.6 The measure measures itself | L3.2 (Evidence Over Assumption) |

**Action:** Add a "Derived Operational Principles" section to L3 referencing the Operating Framework, or add the Operating Framework as an L3 companion document.

### L3 Future Considerations Update

L3 item #3 (Confidence Gating) is now addressed by R2 (Confidence Scoring) in the Requirements Specification. Update status from "Investigate" to "Specified — see R2".

L3 item #4 (S27 Breath Model) aligns with The Measure's four-phase cycle (Observe → Accumulate → Consolidate → Emerge changed). Note the alignment.

### L4 Structure Extension

The L4 directory gains new files:

```
L4/
├── README.md                        # Update index
├── project_requirements.md          # Unchanged
├── agent_user_requirements.md       # Unchanged
├── technical_requirements.md        # Update: reference new docs
├── functional_requirements.md       # Extend: add R1-R18 to REQ registry
├── the_measure.md                   # NEW: foundational theory
├── operating_framework.md           # NEW: principles, ceremonies, assets
├── integration_analysis.md          # NEW: framework ↔ harness mapping
└── requirements_specification.md    # NEW: R1-R18 bridging requirements
```

Alternatively, The Measure and Operating Framework could sit at L3-level as companion documents rather than inside L4, since they contain principles (immutable) not implementation (dynamic). **This is a design decision for the operator.**

### Five-Layer Hierarchy Provenance

The five-layer hierarchy discovered in E2.4 Session 265 (Principles → Ways of Working → Ceremonies → Activities → Assets) is the same structure as the Operating Framework. The technical_requirements.md should note this provenance — the pattern was discovered independently through implementation, then formalised in the Operating Framework with temporal grounding from The Measure.

### Ceremony System Extension

The existing 20 ceremonies (Queue, Session, Closure, Memory, Feedback, Spawn) are **state-transition ceremonies** — they fire when work state changes.

The Measure adds **temporal ceremonies** — they fire on time-based rhythms:

| Temporal Ceremony | Scale | Purpose |
|---|---|---|
| Pulse | ~90-120 min | One observation-action-logging unit |
| Day | 24h | Compress pulse data into daily signals |
| Calibration | ~29.5 days | Analyse performance, assess threshold drift |
| Evolution | ~29.5 days | Act on calibration: retrain, reconfigure |
| Expansion | ~90 days | Audit for new application opportunities |
| Orbit | 365 days | Strategic assessment, test The Measure's hypotheses |

**These two ceremony types coexist.** State-transition ceremonies handle operational flow. Temporal ceremonies handle learning and self-improvement. They are complementary, not competing.

**Action:** Add a "Temporal Ceremonies" section to technical_requirements.md or create a dedicated ceremony architecture document.

### REQ Registry Extension

The following new requirements from the Requirements Specification should be added to functional_requirements.md's master registry:

| New ID | Maps To Existing | Status |
|---|---|---|
| R1 (Decision Logging) | Extends REQ-OBSERVE-001 to 004 | New — P0 |
| R2 (Confidence Scoring) | Addresses L3 Future #3 | New — P0 |
| R3 (Message Bus) | No existing equivalent — cross-system | New — P1 |
| R4 (Capability Registry) | Extends REQ-CONFIG-005 | New — P0 |
| R5 (Cascade Router) | No existing equivalent | New — P1 |
| R6 (Daily Signal Compression) | No existing equivalent | New — P1 |
| R7 (Calibration Support) | No existing equivalent | New — P1 |
| R8 (Evolution Support) | Parallels REQ-FEEDBACK-004 | New — P2 |
| R9 (Thread Lifecycle) | No existing equivalent — cross-system | New — P1 |
| R10 (Shared Reference Context) | No existing equivalent — cross-system | New — P2 |
| R11 (Observability as Feedback) | Extends REQ-OBSERVE-* + REQ-FEEDBACK-* | New — P1 |
| R12 (Temporal Tagging) | No existing equivalent | New — P1 |
| R13 (Agent Invocation) | No existing equivalent — cross-system | New — P2 |
| R14 (Performance Baselines) | No existing equivalent | New — P2 |
| R15 (Timing Performance Data) | No existing equivalent | New — P3 |
| R16 (Pattern Library) | No existing equivalent | New — P2 |
| R17 (Declarative Tool Entry) | Extends REQ-CONFIG-005 | New — P1 |
| R18 (Human-as-Layer Logging) | No existing equivalent | New — P1 |

**ID Convention Decision Required:** The new requirements use R1-R18 format. Existing requirements use REQ-DOMAIN-NNN format. Options:
1. Renumber R1-R18 into REQ-DOMAIN-NNN format (consistent, requires mapping table)
2. Keep R1-R18 as-is (distinct origin, easy to identify as "foundational" requirements)
3. Prefix as REQ-FOUND-001 through REQ-FOUND-018 (compromise)

**Recommendation:** Option 2 for now. The R-prefix distinguishes requirements derived from the foundational documents vs requirements derived from L3 principles. They trace to different source documents.

### Epoch Implications

The current E2.5 (Independent Lifecycles) is not affected. The new requirements are P0-P3 priority and can be scheduled into future epochs:

| Priority | When | What |
|---|---|---|
| P0 | Next epoch or late E2.5 | R1 (Decision Logging), R2 (Confidence Scoring), R4 (Capability Registry) |
| P1 | Following epoch | R3 (Message Bus), R5 (Cascade Router), R6, R7, R9, R11, R12, R17, R18 |
| P2 | Requires multi-system | R8, R10, R13, R14, R16 |
| P3 | Vision-tier | R15 (Timing Performance Data) |

P0 items map to existing Chariot capabilities and can be built without the Harness infrastructure. They are the foundation everything else depends on.

---

## The Three Primitives

All new documents reduce to the same three primitives already established in The Harness:

1. **Agents** — Actors that produce and consume
2. **Messages** — What moves between them
3. **Context** — What shapes behaviour

These are the DNA. L0-L4 is the soul. The Measure is the physics. The Operating Framework is the policy. The Harness is the plumbing. The Chariot is the workhorse that builds all of it.

---

## Synthesis Instructions

To produce a new manifesto version, the pipeline should:

1. **Load** L0-L3 as immutable ground truth
2. **Load** the four new foundational documents as source corpus
3. **Load** this integration brief as the mapping specification
4. **Produce** updated L3 with derived operational principles section
5. **Produce** updated L4 README with new file index
6. **Produce** updated technical_requirements.md with temporal ceremonies and five-layer provenance
7. **Produce** updated functional_requirements.md with R1-R18 in the master registry
8. **Validate** every new requirement traces to L3 principles (all do — see Requirements Specification traceability tags)
9. **Do not modify** L0, L1, L2, or any existing REQ-* entries

The new documents themselves (Measure, Framework, Integration Analysis, Requirements Specification) should be placed in the manifesto structure per the operator's decision on L3-level vs L4-level placement.

---

## Open Decision for Operator

**Where do The Measure and Operating Framework live in the hierarchy?**

| Option | Placement | Rationale |
|---|---|---|
| A | L3 companion documents | They contain principles (immutable). They derive from L0-L2. They govern L4. |
| B | L4 subdirectory | They inform implementation. They will be tested and may evolve. |
| C | New level (L3.5 or equivalent) | They sit between principles and implementation — more concrete than L3, more strategic than L4. |
| D | Outside the L-hierarchy entirely | They are the physics. The L-hierarchy operates within them. |

**Recommendation:** Option A or D. The Measure and Operating Framework are not implementation details — they are governing constraints. They should not be inside L4 where they'd be treated as dynamic.

---

*This document is consumed once. It produces a new manifesto version. Then it becomes historical context.*
