# Integration Analysis: Operating Framework ↔ The Harness

*This document maps the relationship between the HAIOS Operating Framework and The Harness (Org Instance Design). It identifies where they align, where they diverge, and what work closes the gap.*

---

## The Three Layers

| Layer | Document | Governs |
|---|---|---|
| Physics | The Measure | Why these rhythms |
| Policy | Operating Framework | When and how to act |
| Plumbing | The Harness | How things move |

---

## Direct Mappings

**The Harness's three primitives (Agents, Messages, Context)** map to the Operating Framework's core logic. Agents are the layers in the cascade. Messages are decision logs. Context is system configuration + capability registry.

**"State is filtered event history context injection"** — this is the same insight as Principle 2 ("Every execution is training data") and the asset model where decision logs are the foundational layer everything else derives from.

**The three-system architecture (Coordination, Org, Observability)** maps to the asset categories:

| Harness System | Operating Framework Assets |
|---|---|
| Coordination | System configuration, capability registry |
| Org | Learned weights, training sets, capability registry |
| Observability | Decision logs, daily signals, performance baselines, timing performance data |

**Thread lifecycle (open → play → result → closed)** maps to the four-phase cycle from The Measure: Observe → Accumulate → Consolidate → Emerge changed. A thread *is* one pass through that cycle at the pulse scale.

**"Routing is the only infrastructure concern"** — this is the cascade classifier. The entire framework is about routing decisions to the cheapest viable resolution layer.

---

## Divergences

**The Harness has no temporal structure.** There's no concept of ceremonies, rhythms, or consolidation phases. Messages flow continuously. There's no rest phase, no distinction between active operation and learning. The bus runs, but it doesn't *learn from running* on any structured cadence.

**Observability is downstream-only.** In the Harness, observability receives emissions — it's a record. In the Operating Framework, observability *feeds back* into the system through ceremonies. The logs become training sets become learned weights. The Harness captures the data. The Framework says what to do with it and when.

**No confidence scoring.** The Harness routes by type and destination — deterministic routing. The Framework routes by confidence — probabilistic. The bus currently doesn't ask "how sure am I this should go to the trader?" It just routes. This is where the cascade pattern would plug in: routing logic that considers confidence, not just destination.

**No self-improvement loop.** The Harness is infrastructure. It moves things. It doesn't get better at moving things. The Framework demands that the system teaches itself. The gap is: where does the feedback loop live in the bus architecture?

---

## The Integration

The Harness is the **nervous system**. The Operating Framework is the **endocrine system**. One handles fast signalling (messages, routing, handoffs). The other handles slow regulation (learning cycles, threshold tuning, capability evolution).

They are complementary systems that need connecting. Specifically:

**The bus needs a temporal layer.** Not every message is equal. Some are pulse-level operations (chess moves, trade executions). Some are calibration-level signals (this routing pattern keeps failing). Some are evolution-level data (accumulated performance over a lunar cycle). The message schema doesn't currently distinguish between these.

**Observability needs to feed ceremonies.** Right now: `bus log` shows what happened. Under the Framework: daily signals compress those logs. Calibration analyses them for drift. Evolution acts on them. The Harness already captures everything — it just needs ceremony hooks that process the captured data at the right rhythms.

**The daemon is the proto-cascade.** The future daemon that watches for pending messages and invokes agents — that's Layer 1 of the cascade. It's deterministic now (hardcoded routing). The Framework says: let it learn. Log its routing decisions, measure outcomes, eventually train a model to replace the hardcoded rules.

**A concrete integration point:** add a `ceremony_scale` field to messages or threads. Tag whether something is pulse, daily, calibration, evolution, expansion, orbit. The bus routes as before, but now the temporal layer can query: "give me everything tagged calibration from the last lunar cycle" and feed it into the ceremony.
