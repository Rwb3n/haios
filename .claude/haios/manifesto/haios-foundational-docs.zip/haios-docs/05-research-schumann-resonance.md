# Schumann Resonance and Biology: Real Physics, Real Rhythms, Tenuous Connections

*Research compiled to inform The Measure — HAIOS Foundational Theory. This document contains the evidence base and epistemic assessment that grounds the cosmological framing.*

---

**Summary:** The frequencies of Earth's electromagnetic heartbeat overlap with those of the human brain, but the scientific case for a causal link remains weak and plagued by a devastating signal-strength problem. Schumann resonances (SR) — standing electromagnetic waves in the Earth-ionosphere cavity at ~7.83 Hz and higher modes — are well-established geophysics. Brainwaves span 0.5–100+ Hz, so frequency overlap is statistically inevitable rather than remarkable. Yet a persistent 70-year research thread, ranging from legitimate Max Planck experiments to predatory-journal speculation, has explored whether these planetary rhythms couple to biological oscillators. Meanwhile, genuine harmonic nesting *within* biology — 12-hour and 8-hour gene expression rhythms as integer harmonics of the circadian clock, theta-gamma cross-frequency coupling in the brain, and fractal 1/f dynamics in healthy physiology — is robustly established. The challenge is distinguishing these real nested rhythms from the unproven claim that they connect downward to geophysical electromagnetic frequencies.

---

## The Physics: What Schumann Resonances Actually Are

Schumann resonances are electromagnetic standing waves trapped between Earth's surface and the ionosphere, excited by the planet's ~50 lightning flashes per second. Winfried Otto Schumann predicted them in 1952; Balser and Wagner confirmed them experimentally in 1960–1963. The fundamental frequency arises because Earth's circumference (~40,000 km) approximates one wavelength at ~7.83 Hz. Higher modes follow the formula f_n ≈ 6 × √(n(n+1)) Hz, yielding observed peaks at approximately 7.83, 14.3, 20.8, 27.3, and 33.8 Hz. Crucially, these are not integer harmonics — they follow a spherical-cavity eigenvalue progression, spacing modes ~6.5 Hz apart rather than at integer multiples of the fundamental. SR magnetic field amplitudes sit in the picotesla range (~10⁻¹² T), with electric fields on the order of microvolts per meter. For context, Earth's static geomagnetic field is ~50 µT — roughly 50 million times stronger — and WHO-established thresholds for biological effects of ELF fields begin above 100 µT, some 100 billion times the SR signal.

## Where the Evidence is Strongest: ELF Bioeffects and the Wever Experiments

The most credible thread connecting ELF fields to biology involves three lines of evidence, none of which specifically demonstrates SR coupling but which establish that biological tissue can respond to weak oscillating fields in the SR frequency range.

**Calcium ion efflux experiments** represent the best-replicated laboratory finding. Bawin and Adey (1976) published in PNAS that weak sinusoidal electric fields at 6 and 16 Hz caused 12–15% changes in calcium efflux from cerebral tissue, with specific frequency and amplitude "windows" of effectiveness. Blackman et al. at the EPA (1979, 1985) independently confirmed these window effects in Bioelectromagnetics.

**Wever's bunker experiments** at the Max Planck Institute (1964–1989) remain the most-cited evidence. Over 25 years, 447 volunteers lived in underground bunkers, some electromagnetically shielded. In the shielded room, circadian periods lengthened beyond 25 hours. A 10 Hz electric field introduced into the shielded room consistently restored normal circadian periodicity. However, the bunker excluded all other time cues, and the effect has never been replicated with modern methods.

**Recent cardiac and epidemiological studies** provide the most interesting modern data. Elhalel et al. (2019) in Scientific Reports showed cardioprotective effects of 7.8 Hz magnetic fields on rat cardiomyocytes. Fdez-Arroyabe et al. (2020) found correlations between SR power minima and cardiovascular hospital admissions. These are published in reputable journals but share important limitations: small sample sizes and correlational designs.

## Genuine Harmonic Nesting Within Biology

While the SR-to-biology connection remains unproven, harmonic nesting within biological systems is robustly established across multiple scales.

**Gene expression profiling:** Zhu, Dacso, and O'Malley (2018) documented that mammalian hepatic gene expression oscillates at 24-hour, 12-hour, 8-hour, and 6-hour periods — the first through fourth harmonics of a circadian fundamental.

**Cross-frequency coupling:** Belluscio et al. (2012) demonstrated theta-gamma phase-phase coupling in hippocampus at approximately 1:5 and 1:9 integer ratios. This is mainstream, well-replicated science.

**Fractal dynamics:** Healthy physiology exhibits fractal 1/f power-law correlations across timescales, as demonstrated by Goldberger et al. (2002) in PNAS. Loss of this fractal structure correlates with disease and aging.

**Ultradian rhythms:** Kleitman's ~90-minute Basic Rest-Activity Cycle divides into the 24-hour day exactly 16 times (2⁴).

## Lunar Rhythms

Circalunar clocks are genuine endogenous oscillators in marine organisms. Helfrich-Förster et al. (2021) in Science Advances found intermittent synchronisation of menstrual cycles with lunar luminance and gravimetric cycles. Kaiser and Neumann (2021) proposed semilunar rhythms arise from beat coincidence between circadian and circatidal oscillators.

## Mathematical Frameworks

Pikovsky, Rosenblum, and Kurths' 2001 monograph Synchronization: A Universal Concept in Nonlinear Sciences establishes that any weak periodic forcing will tend to lock oscillators to nearby rational frequency ratios (Arnold tongues). Stochastic resonance — where background noise enhances detection of weak periodic signals — offers the most physically plausible mechanism for SR amplification, but remains hypothetical.

Bank and Scafetta (2022) showed ratios of neighboring planetary orbital radii correspond to musical consonances with p < 0.001. West, Brown, and Enquist's quarter-power allometric scaling laws (1997, Science) provide universal cross-scale biological frequency relationships.

## Credibility Assessment

The SR-biology literature occupies a wide credibility spectrum. The signal strength problem remains fundamental: SR fields at ~1 pT are approximately 100 billion times weaker than WHO-established thresholds for ELF biological effects.

**Established:** SR physics, biological harmonic nesting, cross-frequency coupling, fractal physiology, circalunar clocks in marine organisms.

**Plausible but unproven:** Calcium efflux window effects at SR frequencies, Wever's circadian field experiments, stochastic resonance amplification.

**Fringe:** Commercial Schumann resonators, Michael Persinger's broader claims (predatory journals, unreplicated results), direct causal SR-health links.

## Conclusion

Nested rhythms are real within biology. The planetary electromagnetic connection is not established. The correct framing is an underpowered hypothesis with some intriguing laboratory evidence, no demonstrated mechanism at ambient field strengths, and severe signal-to-noise challenges.
